<form action="../../../controller/getLogin.php" method="post">
	<div>
		<dir>
			<div class="col-4 d-flex align-items-center">
				<label>Correo</label>
			</div>
			<div>
				<input type="text" name="user">
			</div>			
		</dir>
		<dir>
			<div>
				<label>Contraseña</label>
			</div>
			<div>
				<input type="password" name="pass">
			</div>			
		</dir>			
	</div>
	<div>
		<dir>
			<input type="submit" name="btnUno" value="Boton Uno">
			<input type="submit" name="btnDos" value="Boton Dos">
		</dir>
		
	</div>
</form>