<?php
class controllerPrincipal{

	public function controllerView(){
		
		include_once("view/principal.php");
		
	}
	
}
?>