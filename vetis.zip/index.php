<?php

include_once("controller/controllerPrincipal.php");
$principal = new controllerPrincipal;
$principal -> controllerView();
?>